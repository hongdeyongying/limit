#if !defined(AFX_ERRORCODEFRAME_H__E335186E_A085_4D74_8216_63C2943DC5B2__INCLUDED_)
#define AFX_ERRORCODEFRAME_H__E335186E_A085_4D74_8216_63C2943DC5B2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ErrorCodeFrame.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CErrorCodeFrame frame

class CErrorCodeFrame : public CMDIChildWnd
{
	DECLARE_DYNCREATE(CErrorCodeFrame)
protected:
	CErrorCodeFrame();           // protected constructor used by dynamic creation

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CErrorCodeFrame)
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CErrorCodeFrame();

	// Generated message map functions
	//{{AFX_MSG(CErrorCodeFrame)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ERRORCODEFRAME_H__E335186E_A085_4D74_8216_63C2943DC5B2__INCLUDED_)
