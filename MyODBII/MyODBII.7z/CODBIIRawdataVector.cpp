
#include "stdafx.h"

#ifndef CODBIIRAWDATAVECTOR_CPP_HEADER_INCLUDED_B1C48313
#define CODBIIRAWDATAVECTOR_CPP_HEADER_INCLUDED_B1C48313

#include "CODBIIRawdataVector.h"

CODBIIRawdataVector g_objCODBIIRawdataVector;

//order list 
CODBIIRawdataVector g_cmdCODBIIRawdataVector;


CMutex  g_mutexCODBIIRawdata(FALSE,"CODBIIRawdataVector");

#endif /* CODBIIRAWDATAVECTOR_CPP_HEADER_INCLUDED_B1C48313 */

