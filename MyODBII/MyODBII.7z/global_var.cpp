
#include "global_var.h"

MyConfig::CConfigEntry g_objCConfigEntry;