#if !defined(AFX_SENSORSDATAFRAME_H__8F6FFD59_0DFF_41A8_AA00_83A7181187A1__INCLUDED_)
#define AFX_SENSORSDATAFRAME_H__8F6FFD59_0DFF_41A8_AA00_83A7181187A1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SensorsDataFrame.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSensorsDataFrame frame

class CSensorsDataFrame : public CMDIChildWnd
{
	DECLARE_DYNCREATE(CSensorsDataFrame)
protected:
	CSensorsDataFrame();           // protected constructor used by dynamic creation

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSensorsDataFrame)
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CSensorsDataFrame();

	// Generated message map functions
	//{{AFX_MSG(CSensorsDataFrame)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SENSORSDATAFRAME_H__8F6FFD59_0DFF_41A8_AA00_83A7181187A1__INCLUDED_)
