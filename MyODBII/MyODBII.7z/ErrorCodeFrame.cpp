// ErrorCodeFrame.cpp : implementation file
//

#include "stdafx.h"
#include "MyODBII.h"
#include "ErrorCodeFrame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CErrorCodeFrame

IMPLEMENT_DYNCREATE(CErrorCodeFrame, CMDIChildWnd)

CErrorCodeFrame::CErrorCodeFrame()
{
}

CErrorCodeFrame::~CErrorCodeFrame()
{
}


BEGIN_MESSAGE_MAP(CErrorCodeFrame, CMDIChildWnd)
	//{{AFX_MSG_MAP(CErrorCodeFrame)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CErrorCodeFrame message handlers
