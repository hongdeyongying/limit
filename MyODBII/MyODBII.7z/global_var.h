#ifndef GLOBAL_VAR_H_20110807
#define GLOBAL_VAR_H_20110807

#include "fileconfig/CConfigEntry.h"
#include "CSensorDataVectorMap.h"

extern MyConfig::CConfigEntry g_objCConfigEntry;


#define MYMSG_ORDER_EXEC_END (WM_USER+5819)
#define MYMSG_DISP_CARINFO (WM_USER+5818)

#endif
