//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MyODBII.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_SOCKETS_INIT_FAILED         104
#define IDR_MAINFRAME                   128
#define IDR_MYODBITYPE                  129
#define IDR_MYLOGTYPE                   130
#define IDD_DIALOG_SETTING              130
#define IDR_ERRCDTYPE                   131
#define IDR_SENSORTYPE                  132
#define IDC_EDIT_COM                    1002
#define IDC_EDIT_BOUNDRATE              1003
#define MENU_COMM_CONFIG                32771
#define MENU_ODBII_BEGIN                32772
#define MENU_ODBII_END                  32773
#define MENU_VIEW_LOG                   32774
#define MENU_VIEW_SENSORS               32776
#define MENU_VIEW_TROUBLE_CODE          32777
#define BTN_CAPTURE                     32779
#define BTN_STOP                        32780
#define MENU_REFRESH                    32783
#define MENU_CLEAR_TCD                  32787
#define ID_SEPARATORdd                  32788
#define ID_INDICATOR_OBDII              59142
#define STR_ERR_COMM_OPEN               61447
#define STR_ERR_ALREADY_RUN             61448

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32789
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
