#ifndef CSENSORDATAVECTOR_H_HEADER_INCLUDED_B1C091F7
#define CSENSORDATAVECTOR_H_HEADER_INCLUDED_B1C091F7

#include <vector>

#include "CSensordata.h"
//##ModelId=4E3F2AA20034
typedef std::vector<CSensorData> CSensorDataVector;



#endif /* CSENSORDATAVECTOR_H_HEADER_INCLUDED_B1C091F7 */
