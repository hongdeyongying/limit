
#include "CSensorDataVectorMap.h"

CSensorDataVectorMap g_objCSensorDataVectorMap;

CECUSensorDataVectorMap g_objCECUSensorDataVectorMap;

CECUCarInfoMap g_objCECUCarInfoMap;