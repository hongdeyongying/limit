//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Analyzer.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_ANALYZER_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDR_MENU1                       129
#define IDC_EDIT1                       1000
#define IDC_TREE1                       1001
#define IDFILE                          1002
#define IDC_EDIT2                       1003
#define IDC_BUTTON1                     1004
#define IDC_BUTTON_begin                1005
#define IDC_BUTTON_mid                  1006
#define IDC_BUTTON_end                  1007
#define IDC_BUTTON_Clear                1008
#define IDC_EDIT_PARAM                  1009
#define IDC_BUTTON_S_TAG                1010
#define IDC_BUTTON_S_ID                 1011
#define IDC_BUTTON_S_NAME               1012
#define IDC_EDIT_PARAM2                 1013
#define BTN_NV                          1014
#define IDC_EDIT_TAGNAME_MODE           1015
#define IDC_BUTTON2                     1016
#define IDC_RICHEDIT1                   1017
#define ID_MENUITEM_ONLINE              32771
#define ID_MENUITEM_MAN                 32772
#define ID_MENUITEM_VER                 32773

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32774
#define _APS_NEXT_CONTROL_VALUE         1018
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
