// IESync.h : Declaration of the CIESync

#ifndef __IESYNC_H_
#define __IESYNC_H_

#include "resource.h"       // main symbols


#include <mshtml.h>
#include<string>
#include<vector>
using namespace std;

/////////////////////////////////////////////////////////////////////////////
// CIESync
class ATL_NO_VTABLE CIESync : 
	public CComObjectRootEx<CComMultiThreadModel>,
	public CComCoClass<CIESync, &CLSID_IESync>,
	public IObjectWithSiteImpl<CIESync>,
	public IDispatchImpl<IIESync, &IID_IIESync, &LIBID_ASYNCALLLib>
{
		CComQIPtr <IDispatch> m_spCallBack; 

CComQIPtr<IHTMLDocument2> m_doc;
string m_strPara;
public:
	static DWORD WINAPI ThreadProc(void *p);
	CIESync()
	{
	}
static HRESULT  ExecJavascript(const string & sFuncName, const   vector <VARIANT> & pVectorParas,CComQIPtr<IHTMLDocument2>& pdoc) 
{	
	HRESULT hResult;
	//(1)Get   Script   
	CComPtr <IDispatch>   pScript; 

	hResult   =   pdoc->get_Script(&pScript); 
	if(FAILED(hResult)) 
	{ 
MessageBox(NULL,__FILE__,"00",MB_OK);
		return   FALSE; 
	} 	
	//(2)Get   Javascript   Function 
	CComBSTR   pCComBSTR(sFuncName.c_str()); 
	DISPID   pDISPID; 
	hResult   =   pScript-> GetIDsOfNames(IID_NULL,   &pCComBSTR,   1,   LOCALE_SYSTEM_DEFAULT,   &pDISPID); 
	if(FAILED(hResult)) 
	{ 
MessageBox(NULL,__FILE__,"11",MB_OK);
		return   FALSE; 
	} 
	
	//(3)Add   Parameters 
	DISPPARAMS   pDISPPARAMS; 
	memset(&pDISPPARAMS,   0,   sizeof(pDISPPARAMS)); 
	
	int   iParaCount   =   pVectorParas.size(); 

	VARIANT*   vParams = NULL;
	if(iParaCount > 0)
		vParams   =   new   VARIANT[iParaCount]; 
	


	for(   int   i   =   0;   i   <   iParaCount;   i++) 
	{ 
		vParams[i]   =   pVectorParas[i];   
	} 
	
	//Params   Count 
	pDISPPARAMS.cArgs   =   iParaCount; 
	//Params   Array 
	pDISPPARAMS.rgvarg   =   vParams; 
	//Name   Args   Count 
    pDISPPARAMS.cNamedArgs   =   0; 
	
	//(4)Invoke   Javascript   Method 
	EXCEPINFO   pEXCEPINFO; 
	memset(&pEXCEPINFO,   0,   sizeof(pEXCEPINFO)); 
	
	CComVariant   pCComVariant; 
	
	//Initialize   to   invalid   arg 
	UINT   nintArgErr   =   (UINT)-1;     
	
MessageBox(NULL,__FILE__,"222222222",MB_OK);
	hResult   =   pScript-> Invoke 
		(pDISPID,   IID_NULL,   0,   DISPATCH_METHOD,   &pDISPPARAMS,   &pCComVariant,   &pEXCEPINFO,   &nintArgErr); 
	
	delete[]   pDISPPARAMS.rgvarg; 
	pScript.Release(); 
	
	if(FAILED(hResult)) 
	{ 
		USES_CONVERSION;
MessageBox(NULL,W2A(pEXCEPINFO.bstrDescription),"222222222",MB_OK);
//MessageBox(NULL,W2A(pEXCEPINFO.bstrSource),"222222222",MB_OK);
		return   FALSE; 
	} 
	
	return   TRUE; 
	
}

DECLARE_REGISTRY_RESOURCEID(IDR_IESYNC)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CIESync)
	COM_INTERFACE_ENTRY(IIESync)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(IObjectWithSite)
END_COM_MAP()

// IIESync
public:
	void FireEvent();
	STDMETHOD(put_CallBack)(/*[in]*/ VARIANT* newVal);
	STDMETHOD(Do)(/*[in]*/IDispatch * pDispatch,/*[in]*/BSTR para);
};

#endif //__IESYNC_H_
