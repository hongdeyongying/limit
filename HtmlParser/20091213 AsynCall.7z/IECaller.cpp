// IECaller.cpp : Implementation of CIECaller
#include "stdafx.h"
#include "AsynCall.h"
#include "IECaller.h"

/////////////////////////////////////////////////////////////////////////////
// CIECaller

STDMETHODIMP CIECaller::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IIECaller
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CIECaller::JustDo(IDispatch *pDispatch)
{
	USES_CONVERSION;
	// TODO: Add your implementation code here
	m_doc =  pDispatch;

	BSTR bstr = NULL;
	m_doc->get_title (&bstr);

	const char * pszTitle = W2A(bstr);

	MessageBox(NULL,pszTitle,"",MB_OK);

	CComBSTR bstr1("Hello world!");

	m_doc->put_title(bstr1);

	return S_OK;
}

HRESULT  CIECaller::ExecJavascript(const string & sFuncName, const   vector <VARIANT> & pVectorParas) 
{	
	HRESULT hResult;
	//(1)Get   Script   
	CComPtr <IDispatch>   pScript; 

	hResult   =   m_doc->get_Script(&pScript); 
	if(FAILED(hResult)) 
	{ 
		return   FALSE; 
	} 	
	//(2)Get   Javascript   Function 
	CComBSTR   pCComBSTR(sFuncName.c_str()); 
	DISPID   pDISPID; 
	hResult   =   pScript-> GetIDsOfNames(IID_NULL,   &pCComBSTR,   1,   LOCALE_SYSTEM_DEFAULT,   &pDISPID); 
	if(FAILED(hResult)) 
	{ 
		return   FALSE; 
	} 
	
	//(3)Add   Parameters 
	DISPPARAMS   pDISPPARAMS; 
	memset(&pDISPPARAMS,   0,   sizeof(pDISPPARAMS)); 
	
	int   iParaCount   =   pVectorParas.size(); 

	VARIANT*   vParams = NULL;
	if(iParaCount > 0)
		vParams   =   new   VARIANT[iParaCount]; 
	


	for(   int   i   =   0;   i   <   iParaCount;   i++) 
	{ 
		vParams[i]   =   pVectorParas[i];   
	} 
	
	//Params   Count 
	pDISPPARAMS.cArgs   =   iParaCount; 
	//Params   Array 
	pDISPPARAMS.rgvarg   =   vParams; 
	//Name   Args   Count 
    pDISPPARAMS.cNamedArgs   =   0; 
	
	//(4)Invoke   Javascript   Method 
	EXCEPINFO   pEXCEPINFO; 
	memset(&pEXCEPINFO,   0,   sizeof(pEXCEPINFO)); 
	
	CComVariant   pCComVariant; 
	
	//Initialize   to   invalid   arg 
	UINT   nintArgErr   =   (UINT)-1;     
	
//MessageBox(NULL,__FILE__,"222222222",MB_OK);
	hResult   =   pScript-> Invoke 
		(pDISPID,   IID_NULL,   0,   DISPATCH_METHOD,   &pDISPPARAMS,   &pCComVariant,   &pEXCEPINFO,   &nintArgErr); 
	
	delete[]   pDISPPARAMS.rgvarg; 
	pScript.Release(); 
	
	if(FAILED(hResult)) 
	{ 
		USES_CONVERSION;
//MessageBox(NULL,W2A(pEXCEPINFO.bstrDescription),"222222222",MB_OK);
//MessageBox(NULL,W2A(pEXCEPINFO.bstrSource),"222222222",MB_OK);
		return   FALSE; 
	} 
	
	return   TRUE; 
	
}

STDMETHODIMP CIECaller::RunScript(BSTR fname, BSTR para)
{
	USES_CONVERSION;

	string sFname = W2A(fname);
	string sPara = W2A(para);
	// TODO: Add your implementation code here
	vector <VARIANT>   arrPara;

	arrPara.push_back(CComVariant(sPara.c_str()));
	//arrPara.Add (CComVariant(123));

	ExecJavascript(sFname,arrPara);
	return S_OK;
}

DWORD WINAPI CIECaller::ThreadProc(void *p)
{
	CIECaller *pCIECaller = (CIECaller *) p;

	string sFname("Test1");
	string sPara("aaaa");
	// TODO: Add your implementation code here
	vector <VARIANT>   arrPara;
//MessageBox(NULL,__FILE__,"3",MB_OK);
//	Sleep(2000);
//MessageBox(NULL,__FILE__,"4",MB_OK);
	arrPara.push_back(CComVariant(sPara.c_str()));
	//arrPara.push_back(CComVariant(sPara.c_str()));
	//arrPara.Add (CComVariant(123));
//CComBSTR bstr1("temp!");

//	pCIECaller->m_doc->put_title(bstr1);


	pCIECaller->ExecJavascript(sFname,arrPara);
//MessageBox(NULL,__FILE__,"5",MB_OK);
	return 1;
}

STDMETHODIMP CIECaller::DoAsynWork(IDispatch *pDispatch)
{
	// TODO: Add your implementation code here
	m_doc =  pDispatch;

	//MessageBox(NULL,__FILE__,"1",MB_OK);
/*	
	DWORD dw;

	HANDLE thread = CreateThread(NULL,0,ThreadProc,this,0,&dw);

	CloseHandle(thread);
//*/
	CIECaller::ThreadProc(this);

	//MessageBox(NULL,__FILE__,"2",MB_OK);
	return S_OK;
}
