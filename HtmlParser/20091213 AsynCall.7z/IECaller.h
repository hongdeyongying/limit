// IECaller.h : Declaration of the CIECaller

#ifndef __IECALLER_H_
#define __IECALLER_H_

#include "resource.h"       // main symbols
#include <mshtml.h>
#include<string>
#include<vector>
using namespace std;

/////////////////////////////////////////////////////////////////////////////
// CIECaller
class ATL_NO_VTABLE CIECaller : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CIECaller, &CLSID_IECaller>,
	public IObjectWithSiteImpl<CIECaller>,
	public ISupportErrorInfo,
	public IDispatchImpl<IIECaller, &IID_IIECaller, &LIBID_ASYNCALLLib>
{
public:

	CComQIPtr<IHTMLDocument2> m_doc;

	static DWORD WINAPI ThreadProc(void *p);

	CIECaller()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_IECALLER)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CIECaller)
	COM_INTERFACE_ENTRY(IIECaller)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
	COM_INTERFACE_ENTRY(IObjectWithSite)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IIECaller
public:
	STDMETHOD(DoAsynWork)(/*[in]*/IDispatch * pDispatch);
	STDMETHOD(RunScript)(/*[in]*/BSTR fname,/*[in]*/BSTR para);
	STDMETHOD(JustDo)(/*[in]*/IDispatch *pDispatch);
	HRESULT  ExecJavascript(
       /*function name */
       const string &  strJsFunctionName_In,   
       /*parameters */
       const   vector <VARIANT>   &pArrVARIANT_Params
       ) ;
private:
};

#endif //__IECALLER_H_
