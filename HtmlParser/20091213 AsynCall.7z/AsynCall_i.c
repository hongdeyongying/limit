/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 5.01.0164 */
/* at Sun Dec 13 09:26:03 2009
 */
/* Compiler settings for G:\My-Soft\����\AsynCall\AsynCall.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID IID_IIECaller = {0x81156474,0xC97F,0x450E,{0x96,0x73,0xEB,0x00,0x29,0xCD,0x0E,0x99}};


const IID IID_IIESync = {0xF291A5A4,0x3014,0x4FCA,{0xB8,0x3E,0x43,0x3E,0x5C,0x0B,0xCF,0xCF}};


const IID LIBID_ASYNCALLLib = {0x9D21950F,0xA225,0x4439,{0x93,0xB0,0x03,0xEB,0xE3,0xA6,0x75,0x08}};


const CLSID CLSID_IECaller = {0x7AACA86D,0x219F,0x426F,{0x80,0xCE,0x40,0xE1,0xD5,0xFD,0xE6,0xD1}};


const CLSID CLSID_IESync = {0x809D9D22,0x2C86,0x4ED5,{0xBA,0xC5,0xF5,0x42,0xE2,0xA7,0xBF,0x18}};


#ifdef __cplusplus
}
#endif

