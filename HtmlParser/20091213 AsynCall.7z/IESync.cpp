// IESync.cpp : Implementation of CIESync
#include "stdafx.h"
#include "AsynCall.h"
#include "IESync.h"

/////////////////////////////////////////////////////////////////////////////
// CIESync

DWORD WINAPI CIESync::ThreadProc(void *p)
{
//AFX_MANAGE_STATE(AfxGetStaticModuleState());
	CIESync * pCIESync = (CIESync *)p;

//	string sFname("Test1");
//	string sPara("1111111111111111111111333333333333");
	// TODO: Add your implementation code here
//	vector <VARIANT>   arrPara;
//MessageBox(NULL,__FILE__,sPara.c_str(),MB_OK);
	Sleep(20000);
//MessageBox(NULL,__FILE__,"4",MB_OK);
//	arrPara.push_back(CComVariant(sPara.c_str()));
	//arrPara.push_back(CComVariant(sPara.c_str()));
	//arrPara.Add (CComVariant(123));
//CComBSTR bstr1("temp!");

//	pCIECaller->m_doc->put_title(bstr1);

	pCIESync->FireEvent();

	//ExecJavascript(sFname,arrPara,m_doc);
//MessageBox(NULL,__FILE__,"5",MB_OK);
	return 1;
}
STDMETHODIMP CIESync::Do(IDispatch *pDispatch, BSTR para)
{
	// TODO: Add your implementation code here
USES_CONVERSION;
	m_doc =  pDispatch;

	m_strPara = W2A(para);
	
	DWORD dw;

	HANDLE thread = CreateThread(NULL,0,ThreadProc,this,0,&dw);

	CloseHandle(thread);
/*
	CIESync::ThreadProc(pDispatch);
//*/
	return S_OK;
}


STDMETHODIMP CIESync::put_CallBack(VARIANT *newVal)
{
//	assert(newVal->vt == VT_DISPATCH); 
  m_spCallBack = V_DISPATCH(newVal); 
  return S_OK; 

}

void CIESync::FireEvent()
{
 if (m_spCallBack) 
  { 
    CComVariant args[2] = {"para1_123", "para2_456"}; 
    DISPPARAMS dp = {args, NULL, 2, 0}; 
    m_spCallBack->Invoke
		(0, IID_NULL, 0, DISPATCH_METHOD, &dp, NULL, NULL, NULL); 
	//	(0, IID_NULL, LOCALE_USE_DEFAULT, DISPATCH_METHOD, &dp, NULL, NULL, NULL); 
	//(pDISPID,   IID_NULL,   0,   DISPATCH_METHOD,   &pDISPPARAMS,   &pCComVariant,   &pEXCEPINFO,   &nintArgErr); ;
  } 

}
