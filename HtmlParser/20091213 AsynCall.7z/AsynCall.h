/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Sun Dec 13 09:26:03 2009
 */
/* Compiler settings for G:\My-Soft\����\AsynCall\AsynCall.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __AsynCall_h__
#define __AsynCall_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __IIECaller_FWD_DEFINED__
#define __IIECaller_FWD_DEFINED__
typedef interface IIECaller IIECaller;
#endif 	/* __IIECaller_FWD_DEFINED__ */


#ifndef __IIESync_FWD_DEFINED__
#define __IIESync_FWD_DEFINED__
typedef interface IIESync IIESync;
#endif 	/* __IIESync_FWD_DEFINED__ */


#ifndef __IECaller_FWD_DEFINED__
#define __IECaller_FWD_DEFINED__

#ifdef __cplusplus
typedef class IECaller IECaller;
#else
typedef struct IECaller IECaller;
#endif /* __cplusplus */

#endif 	/* __IECaller_FWD_DEFINED__ */


#ifndef __IESync_FWD_DEFINED__
#define __IESync_FWD_DEFINED__

#ifdef __cplusplus
typedef class IESync IESync;
#else
typedef struct IESync IESync;
#endif /* __cplusplus */

#endif 	/* __IESync_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __IIECaller_INTERFACE_DEFINED__
#define __IIECaller_INTERFACE_DEFINED__

/* interface IIECaller */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IIECaller;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("81156474-C97F-450E-9673-EB0029CD0E99")
    IIECaller : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE JustDo( 
            /* [in] */ IDispatch __RPC_FAR *pDispatch) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE RunScript( 
            /* [in] */ BSTR fname,
            /* [in] */ BSTR para) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE DoAsynWork( 
            /* [in] */ IDispatch __RPC_FAR *pDispatch) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IIECallerVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IIECaller __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IIECaller __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IIECaller __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IIECaller __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IIECaller __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IIECaller __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IIECaller __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *JustDo )( 
            IIECaller __RPC_FAR * This,
            /* [in] */ IDispatch __RPC_FAR *pDispatch);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *RunScript )( 
            IIECaller __RPC_FAR * This,
            /* [in] */ BSTR fname,
            /* [in] */ BSTR para);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *DoAsynWork )( 
            IIECaller __RPC_FAR * This,
            /* [in] */ IDispatch __RPC_FAR *pDispatch);
        
        END_INTERFACE
    } IIECallerVtbl;

    interface IIECaller
    {
        CONST_VTBL struct IIECallerVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IIECaller_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IIECaller_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IIECaller_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IIECaller_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IIECaller_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IIECaller_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IIECaller_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IIECaller_JustDo(This,pDispatch)	\
    (This)->lpVtbl -> JustDo(This,pDispatch)

#define IIECaller_RunScript(This,fname,para)	\
    (This)->lpVtbl -> RunScript(This,fname,para)

#define IIECaller_DoAsynWork(This,pDispatch)	\
    (This)->lpVtbl -> DoAsynWork(This,pDispatch)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IIECaller_JustDo_Proxy( 
    IIECaller __RPC_FAR * This,
    /* [in] */ IDispatch __RPC_FAR *pDispatch);


void __RPC_STUB IIECaller_JustDo_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IIECaller_RunScript_Proxy( 
    IIECaller __RPC_FAR * This,
    /* [in] */ BSTR fname,
    /* [in] */ BSTR para);


void __RPC_STUB IIECaller_RunScript_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IIECaller_DoAsynWork_Proxy( 
    IIECaller __RPC_FAR * This,
    /* [in] */ IDispatch __RPC_FAR *pDispatch);


void __RPC_STUB IIECaller_DoAsynWork_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IIECaller_INTERFACE_DEFINED__ */


#ifndef __IIESync_INTERFACE_DEFINED__
#define __IIESync_INTERFACE_DEFINED__

/* interface IIESync */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IIESync;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("F291A5A4-3014-4FCA-B83E-433E5C0BCFCF")
    IIESync : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Do( 
            /* [in] */ IDispatch __RPC_FAR *pDispatch,
            /* [in] */ BSTR para) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_CallBack( 
            /* [in] */ VARIANT __RPC_FAR *newVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IIESyncVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IIESync __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IIESync __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IIESync __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IIESync __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IIESync __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IIESync __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IIESync __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Do )( 
            IIESync __RPC_FAR * This,
            /* [in] */ IDispatch __RPC_FAR *pDispatch,
            /* [in] */ BSTR para);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_CallBack )( 
            IIESync __RPC_FAR * This,
            /* [in] */ VARIANT __RPC_FAR *newVal);
        
        END_INTERFACE
    } IIESyncVtbl;

    interface IIESync
    {
        CONST_VTBL struct IIESyncVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IIESync_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IIESync_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IIESync_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IIESync_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IIESync_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IIESync_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IIESync_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IIESync_Do(This,pDispatch,para)	\
    (This)->lpVtbl -> Do(This,pDispatch,para)

#define IIESync_put_CallBack(This,newVal)	\
    (This)->lpVtbl -> put_CallBack(This,newVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IIESync_Do_Proxy( 
    IIESync __RPC_FAR * This,
    /* [in] */ IDispatch __RPC_FAR *pDispatch,
    /* [in] */ BSTR para);


void __RPC_STUB IIESync_Do_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IIESync_put_CallBack_Proxy( 
    IIESync __RPC_FAR * This,
    /* [in] */ VARIANT __RPC_FAR *newVal);


void __RPC_STUB IIESync_put_CallBack_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IIESync_INTERFACE_DEFINED__ */



#ifndef __ASYNCALLLib_LIBRARY_DEFINED__
#define __ASYNCALLLib_LIBRARY_DEFINED__

/* library ASYNCALLLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_ASYNCALLLib;

EXTERN_C const CLSID CLSID_IECaller;

#ifdef __cplusplus

class DECLSPEC_UUID("7AACA86D-219F-426F-80CE-40E1D5FDE6D1")
IECaller;
#endif

EXTERN_C const CLSID CLSID_IESync;

#ifdef __cplusplus

class DECLSPEC_UUID("809D9D22-2C86-4ED5-BAC5-F542E2A7BF18")
IESync;
#endif
#endif /* __ASYNCALLLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long __RPC_FAR *, unsigned long            , BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long __RPC_FAR *, BSTR __RPC_FAR * ); 

unsigned long             __RPC_USER  VARIANT_UserSize(     unsigned long __RPC_FAR *, unsigned long            , VARIANT __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  VARIANT_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, VARIANT __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  VARIANT_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, VARIANT __RPC_FAR * ); 
void                      __RPC_USER  VARIANT_UserFree(     unsigned long __RPC_FAR *, VARIANT __RPC_FAR * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
