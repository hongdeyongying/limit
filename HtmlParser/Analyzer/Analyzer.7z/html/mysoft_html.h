// ***********************************************
// �������ڣ� 2009-03-27
// ��    �ߣ� gaussgao
// �����ʼ��� gycommunicate@vip.qq.com
// ��Ҫ���ܣ� ʵ�ֶ�html�ļ��ķ��������Һ͸�ʽ��
// ***********************************************

#ifndef MYSOFT_HTML_H_HEADER_INCLUDED_B62B0410
#define MYSOFT_HTML_H_HEADER_INCLUDED_B62B0410

#pragma warning(disable:4786) 
#pragma warning(disable:4530)

//#define ASSERT(expr) assert(expr)

#include <assert.h>

#include <string>
#include <set>
#include <map>
#include <vector>

#include <algorithm>


using namespace std;

#include "ESTATE.h"
#include "ESYMBOL.h"
#include "ETAG.h"
/*
#include "CAttribute.h"
#include "CBase.h"
#include "CElement.h"
#include "CHtml.h"
#include "CHtmlTagMap.h"
#include "CNode.h"
#include "CTag.h"
#include "CTagMap.h"
#include "CText.h"

*/


#endif /* MYSOFT_HTML_H_HEADER_INCLUDED_B62B0410 */
